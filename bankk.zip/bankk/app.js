const express = require("express")
const bodyParser = require("body-parser")
const ejs = require("ejs")
const mysql = require("mysql")

const app = express()

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Password@123',
    database: 'bankdb'
})

db.connect((err) => {
    if (err) {
        console.log(err)
    } else {
        console.log("Connected")
    }
})

app.use(express.static("public"));
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true,
}));

app.get('/', function(req, res) {
    res.render("home.ejs")
})

app.get('/add', function(req, res) {
    res.render("user_add.ejs")
})

app.post('/save', function(req, res) {
    let data = { username: req.body.username, email: req.body.email, accountno: req.body.accountno, amount: req.body.amount };
    let sql = "INSERT INTO bank SET ?"
    try {
        db.query(sql, data, function(error, results) {
            if (error) {
                console.log(error)
            }
            res.redirect('/bank')
        })
    } catch (err) {
        console.log(err)
    }
})


app.get("/bank", function(req, res) {
    try {
        db.query("SELECT * FROM bank", function(err, results) {
            if (err) {
                console.log(err)
            }
            console.log(results)
            res.render("add_me", {
                users: results,
            })
        })
    } catch (error) {
        console.log(error)
    }
})

app.get("/edit/:userid", function(req, res) {
    const userid = req.params.userid;
    db.query("SELECT * FROM bank WHERE id= ?", [userid], function(error, results) {
        if (error) {
            console.log(error)
        }
        res.render("update_user", {
            user: results[0]
        })
    })
})

app.post("/update", function(req, res) {
    const userid = req.body.id;

    db.query("SELECT * FROM bank WHERE id= ?", [userid], function(err, result) {
        let add_amount = Number(req.body.amount)
        let available_amount = Number(result[0].amount)

        let amount_added = add_amount + available_amount;
        db.query(`UPDATE bank SET amount = '${amount_added}' WHERE id = ?`, [userid], function(error, result) {
            if (error) {
                console.log(error)
            }
            return res.redirect("/bank")
        })
    })


})

app.get('/delete/:userid', function(req, res) {
    const userid = req.params.userid;
    db.query("DELETE FROM bank WHERE id = ?", [userid], function(err, result) {
        if (err) {
            console.log(err)
        }
        return res.redirect('/bank')
    })
})

app.get('/transfer', function(req, res) {
    res.render("transfer_money.ejs")
})

app.post('/transfer_it', function(req, res) {
    let data_sender = { username: req.body.username_sender, accountno: req.body.accountno_sender }
    let data_receiver = { username: req.body.username_receiver, accountno: req.body.accountno_receiver }

    const amount = req.body.amount
    let amount_to_transfer = Number(amount)
    console.log(data_sender)
    console.log(data_receiver)

    try {
        db.query("SELECT * FROM bank WHERE accountno = ?", [req.body.accountno_sender], (erroe, results) => {
            if (results == '') {
                return res.send("Account not registered")
            }
            if (erroe) {
                console.log(erroe)
            }
            console.log(results)


            let sender_amount = Number(results[0].amount)
            if (amount_to_transfer > sender_amount || sender_amount < 0) {
                return res.send("NOT ENOUGH BALANCE")

            } else {

                let new_sender_amount = sender_amount - amount_to_transfer
                console.log(new_sender_amount)
                db.query(`UPDATE bank SET amount='${new_sender_amount}' WHERE accountno = ?`, [req.body.accountno_sender], async function(errors, ress) {
                    if (errors) {
                        console.lofg(errors)
                    }
                })
                db.query("SELECT * FROM bank WHERE accountno = ?", [req.body.accountno_receiver], async function(err, result) {
                    if (err) {
                        console.log(err)
                    }

                    let receiver_amount = Number(result[0].amount)
                    let new_amount = amount_to_transfer + receiver_amount
                    console.log(new_amount)
                    db.query(`UPDATE bank SET amount='${new_amount}' WHERE accountno = ?`, [req.body.accountno_receiver], function(errorss, resss) {
                        if (errorss) {
                            console.lofg(errors)
                        }
                    })
                })
                return res.redirect('/bank')
            }
        })
    } catch (err) {
        console.log(err)
    }
})


app.listen(3000, function() {
    console.log("Successfully started port on 3000")
})